from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import hashlib

p = 23
g = 5

alice_private = 6
bob_private = 15

alice_public = (g ** alice_private) % p
bob_public = (g ** bob_private) % p

alice_shared = (bob_public ** alice_private) % p
bob_shared = (alice_public ** bob_private) % p

print("Shared Key:", alice_shared)

key = hashlib.sha256(str(alice_shared).encode()).digest()[:16]

message = "Hello Bob"

cipher = AES.new(key, AES.MODE_ECB)
ciphertext = cipher.encrypt(pad(message.encode(), AES.block_size))

print("Encrypted:", ciphertext)

cipher2 = AES.new(key, AES.MODE_ECB)
plaintext = unpad(cipher2.decrypt(ciphertext), AES.block_size)

print("Decrypted:", plaintext.decode())