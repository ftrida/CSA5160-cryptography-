from sklearn.tree import DecisionTreeClassifier

# Sample Dataset

X = [
    [100, 0],
    [150, 0],
    [3000, 1],
    [3500, 1]
]

y = [
    "Normal",
    "Normal",
    "Attack",
    "Attack"
]

model = DecisionTreeClassifier()

model.fit(X, y)

packets = int(input("Packets: "))
failed = int(input("Failed Logins: "))

result = model.predict([[packets, failed]])

print("Prediction:", result[0])