import hashlib
import os

users = {}

def register():
    username = input("Username: ")
    password = input("Password: ")

    salt = os.urandom(16)

    hashed = hashlib.sha256(
        salt + password.encode()
    ).hexdigest()

    users[username] = (salt, hashed)

    print("Registration Successful")

def login():
    username = input("Username: ")
    password = input("Password: ")

    salt, stored_hash = users[username]

    new_hash = hashlib.sha256(
        salt + password.encode()
    ).hexdigest()

    if new_hash == stored_hash:
        print("Login Successful")
    else:
        print("Invalid Password")

register()
login()