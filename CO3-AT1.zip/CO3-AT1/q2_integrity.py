import hashlib

def calculate_hash(filename):
    sha256 = hashlib.sha256()

    with open(filename, "rb") as file:
        while chunk := file.read(4096):
            sha256.update(chunk)

    return sha256.hexdigest()

filename = input("Enter file name: ")

original_hash = calculate_hash(filename)

print("\nOriginal SHA-256 Hash:")
print(original_hash)

input("\nModify the file if desired and press Enter...")

new_hash = calculate_hash(filename)

print("\nNew SHA-256 Hash:")
print(new_hash)

if original_hash == new_hash:
    print("\nFile Integrity Maintained")
else:
    print("\nFile Tampered!")