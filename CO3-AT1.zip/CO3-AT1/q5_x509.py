import ssl
import socket

hostname = "google.com"

context = ssl.create_default_context()

with socket.create_connection((hostname, 443)) as sock:
    with context.wrap_socket(sock, server_hostname=hostname) as ssock:

        cert = ssock.getpeercert()

        print("\nCertificate Details")

        print("\nIssuer:")
        print(cert['issuer'])

        print("\nSubject:")
        print(cert['subject'])

        print("\nValid From:")
        print(cert['notBefore'])

        print("\nValid Until:")
        print(cert['notAfter'])

        print("\nCertificate Verified Successfully")