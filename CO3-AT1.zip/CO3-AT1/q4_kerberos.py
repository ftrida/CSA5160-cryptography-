import time
import secrets

print("=== Kerberos Simulation ===")

client = "Alice"

# AS creates Ticket
ticket = secrets.token_hex(8)

timestamp = int(time.time())

print("\nClient:", client)
print("Ticket Generated:", ticket)
print("Timestamp:", timestamp)

print("\nTicket Sent To Client")

# Validation

received_ticket = ticket
received_timestamp = timestamp

current_time = int(time.time())

if received_ticket == ticket and (current_time - received_timestamp) < 60:
    print("\nAuthentication Successful")
else:
    print("\nAuthentication Failed")